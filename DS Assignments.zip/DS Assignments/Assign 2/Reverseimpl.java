import ReverseModule.*;
import java.lang.Math;

class Reverseimpl extends ReversePOA {
    Reverseimpl() {
        super();
        System.out.println("Reverse Object Created");
    }
    
    public String reverse_string(String name) {
        StringBuffer str = new StringBuffer(name);
        str.reverse();
        return ("Server send: " + str);
    }

    public boolean Odd_Even(int num) {
        return num % 2 == 0;
    }

    public boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
}
