import java.util.Scanner;

public class TokenRing {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter number of nodes you want");
        int nodes=sc.nextInt();
        System.out.println("Ring is Formed as:");
        for(int i=0;i<nodes;i++){
            System.out.print(i+" ");
        }

        int choice=0;
        do {
            System.out.println("Enter the sender");
            int sender=sc.nextInt();
            if(sender < 0 || sender >nodes){
                System.out.println("Enter the sender between 0 and "+nodes);
                System.out.println("Enter the sender");
                sender=sc.nextInt();
            }
            System.out.println("Enter receiver");
            int receiver=sc.nextInt();
            if(receiver < 0 || receiver >nodes){
                System.out.println("Enter the receiver between 0 and "+nodes);
                System.out.println("Enter the receiver");
                receiver=sc.nextInt();
            }

            System.out.println("Enter the data to send");
            int data=sc.nextInt();
            int token=0;
            int i=0;
            System.out.println("Sender "+sender +" sending data"+ data);

            for(i=token;i<sender;i++){
                System.out.print(i+ "-> ");
            }

            for(i=sender;i!=receiver;i=(i+1)%nodes){
                System.out.print(" "+i+" ->");
            }

            System.out.println("Receiver "+receiver+ " Received data");

            token=sender;


            if(i<nodes-1){
                for(;i<nodes;i++){
                    System.out.print(" "+i+" ->");
                }
            }

            System.out.println("Enter the choice 1) for terminate and 0) for continue");
            System.out.println("Token is at"+token);
            choice=sc.nextInt();
            
        } while (choice!=1);
    }
}
