import java.rmi.Naming;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        try {
            String url="rmi://localhost/Server";
            ServerIntf serverIntf = (ServerIntf) Naming.lookup(url);

            System.out.println("Enter the string to check palindrome");
            String str=sc.nextLine();
            System.out.println(serverIntf.pali(str));

            System.out.println("Enter the String to check equal or not");
            String a=sc.nextLine();
            String b=sc.nextLine();
            System.out.println(serverIntf.checkEqual(a,b));

            System.out.println("Enter the number to find square root");
            double num1=sc.nextDouble();
            System.out.println(serverIntf.squareRoot(num1));

            System.out.println("Enter the number to find square of a number");
            double num2=sc.nextDouble();
            System.out.println(serverIntf.square(num2));

            System.out.println("Enter two numbers for All operations");
            double c=sc.nextDouble();
            double d=sc.nextDouble();

            System.out.println("Addtion is "+serverIntf.addition(c, d));
            System.out.println("Multi is "+serverIntf.multiplication(c, d));
            System.out.println("divi is "+serverIntf.division(c, d));
            System.out.println("subtraction is "+serverIntf.subtraction(c, d));

        } catch (Exception e) {
            e.printStackTrace();
        }
        sc.close();
    }
}
