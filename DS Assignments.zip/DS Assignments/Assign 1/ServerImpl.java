import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class ServerImpl extends UnicastRemoteObject implements ServerIntf {

    public ServerImpl() throws RemoteException {
        super();
    }

    public double squareRoot(double n) {
        return Math.sqrt(n);
    }

    public double square(double n) {
        return n * n;
    }

    public double addition(double a, double b) {
        return a + b;
    }

    public double subtraction(double a, double b) {
        return a - b;
    }

    public double multiplication(double a, double b) {
        return a * b;
    }

    public double division(double a, double b) {
        if (b != 0) {
            return a / b;
        }
        return Double.NaN;
    }

    public String pali(String a) {
        int i, j;
        for (i = 0, j = a.length() - 1; i < j; i++, j--) {
            if (a.charAt(i) != a.charAt(j)) {
                return "No";
            }
        }
        return "Yes";
    }

    public String checkEqual(String a, String b) {
        if (a.length() != b.length()) {
            return "No";
        }
        for (int i = 0; i < a.length(); i++) {
            if (a.charAt(i) != b.charAt(i)) {
                return "No";
            }
        }
        return "Yes";
    }
}