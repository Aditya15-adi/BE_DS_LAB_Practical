import java.rmi.*;
interface ServerIntf extends Remote{
    // square root
    // square
    // add sub div mul
    // string pali
    // equal or not
    public double squareRoot(double n) throws RemoteException;
    public double square(double n) throws RemoteException;
    public double addition(double a,double b) throws RemoteException;
    public double subtraction(double a,double b) throws RemoteException;
    public double multiplication(double a,double b) throws RemoteException;
    public double division(double a,double b) throws RemoteException;
    public String pali(String str) throws RemoteException;
    public String checkEqual(String a,String b) throws RemoteException;
}
